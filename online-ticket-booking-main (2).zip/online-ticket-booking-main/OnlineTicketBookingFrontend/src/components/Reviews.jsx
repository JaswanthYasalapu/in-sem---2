const Reviews = () => (
  <div style={{ padding: 40, color: "#ff9100", fontSize: 32 }}>
    Reviews Page Coming Soon!
  </div>
);
export default Reviews;
